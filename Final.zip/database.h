#pragma once
#include <iostream>
#include <string>
#include <set>
#include <map>
#include <vector>
#include <algorithm>
#include <stdexcept>

#include "date.h"

using namespace std;

class Database{
public:
	void Add( const Date& date, const string& event);
	
	ostream& Print( ostream& out ) const;
	
	template<typename Lambda>
	int RemoveIf( const Lambda& predicate ) {
		int n = 0;
		vector<Date> l;
		vector<string>::iterator event_it;
		map<Date, vector<string>> k;
		
		for( auto item : bd ){
			k[item.first].resize(distance(item.second.begin(), item.second.end()));
			event_it = copy_if( item.second.begin(), item.second.end(), k[item.first].begin(), [predicate, item]( const string& s ){
																									return predicate(item.first, s);
																								} );
			k[item.first].resize(distance(k[item.first].begin(),event_it));
		}
		
		for(auto item : k){
			for(auto str_item : item.second){
				last[item.first].erase(find(last[item.first].begin(), last[item.first].end(), str_item));	
				bd[item.first].erase(bd[item.first].find(str_item));	
				n++;
			}
			if(bd[item.first].empty()){
				l.push_back(item.first);
			}	
		}
		
		for( auto item : l ){
			bd.erase(bd.find(item));
			last.erase(last.find(item));
		}
		
		
		return n; 
	}
	
	template<typename Lambda>
	vector<string> FindIf( const Lambda& predicate ) const{
		
		vector<string> result;
		ostringstream ostr;
		vector<string>::iterator event_it;
		map<Date, vector<string>> k;
		
		for( auto item : last ){
			k[item.first].resize(distance(item.second.begin(), item.second.end()));
			event_it = copy_if( item.second.begin(), item.second.end(), k[item.first].begin(), [predicate, item]( const string& s ){
																									return predicate(item.first, s);
																								} );
			k[item.first].resize(distance(k[item.first].begin(),event_it));
		}
		
		for(auto item : k){
			for(auto str_item : item.second){
				ostr << item.first << " " << str_item;
				result.push_back(ostr.str());
				ostr.str("");
			}
		}
		
		return result;
	}
	
	string Last(  const Date& date ) const;
	
private:
  map<Date, set<string>> bd;
  map<Date, vector<string>> last;
};
