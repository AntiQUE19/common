#include "date.h"
#include <vector>

  Date::Date(){}
  Date::Date( int y, int m, int d ){
	year = y;
	month = m;
	day = d;
  }
  
  int Date::GetYear() const{
	return year;  
  }
  
  int Date::GetMonth() const{
	return month;  
  }
  
  int Date::GetDay() const{
	return day;  
  }

bool operator<(const Date& lhs, const Date& rhs){
	return vector<int>( {lhs.GetYear(), lhs.GetMonth(), lhs.GetDay()} ) < vector<int>( {rhs.GetYear(), rhs.GetMonth(), rhs.GetDay()} );//lhs.GetYear() * 10000 + lhs.GetMonth() * 100 + lhs.GetDay() < rhs.GetYear() * 10000 + rhs.GetMonth() * 100 + rhs.GetDay();
};

bool operator==(const Date& lhs, const Date& rhs){
	return vector<int>( {lhs.GetYear(), lhs.GetMonth(), lhs.GetDay()} ) == vector<int>( {rhs.GetYear(), rhs.GetMonth(), rhs.GetDay()} );//lhs.GetYear() * 10000 + lhs.GetMonth() * 100 + lhs.GetDay() < rhs.GetYear() * 10000 + rhs.GetMonth() * 100 + rhs.GetDay();
};

bool operator!=(const Date& lhs, const Date& rhs){
	return ! (vector<int>( {lhs.GetYear(), lhs.GetMonth(), lhs.GetDay()} ) == vector<int>( {rhs.GetYear(), rhs.GetMonth(), rhs.GetDay()} ));//lhs.GetYear() * 10000 + lhs.GetMonth() * 100 + lhs.GetDay() < rhs.GetYear() * 10000 + rhs.GetMonth() * 100 + rhs.GetDay();
};

ostream& operator<<( ostream& out, const Date& date ) {
	out << setfill('0') << setw(4) << date.GetYear() << "-"
					<< setfill('0') << setw(2) << date.GetMonth() << "-"
					<< setfill('0') << setw(2) << date.GetDay();
	return out;
};

Date ParseDate(istream& is) {
	int y, m, d;
	char div;
	
	if(!(is >> y)){
		throw exception();
	}
	/*if(y > 9999){
		throw exception();
	}*/ 	
	
	is.get(div);
	
	if( div != '-' ){
		throw exception();
	}
	
	if(!(is >> m)){
		throw exception();
	}
	
	div = ' ';
	
	is.get(div);
	if( div != '-' ){
		throw exception();
	}
	
	if(!(is >> d)){
		throw exception();
	}
	div = ' ';
	if( is.get(div) && div != ' '){
		throw exception();
	};
	
	if( m < 1 || m > 12){
		throw runtime_error( "Month value is invalid: " + to_string(m) );
	}
	
	if( d < 1 || d > 31){
		throw runtime_error( "Day value is invalid: " + to_string(d) );
	}
	
	return Date(y, m, d);
}
