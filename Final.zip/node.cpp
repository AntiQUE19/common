#include "node.h"

#include <iostream>
using namespace std;
	

bool EmptyNode ::Evaluate( const Date& date, const string& event ) { return true; };

DateComparisonNode::DateComparisonNode( const Comparison& c, const Date& d ) :  dt(d),
																				cmp(c) {};
	
bool DateComparisonNode::Evaluate( const Date& date, const string& event ) {
		switch (static_cast<int>(cmp)){
			case 0:
				return date < dt;
			case 1:
				return !( dt < date);
			case 2:
				return dt < date;	
			case 3:
				return !( date < dt );
			case 4:
				return !(date < dt) && !(dt < date);
			case 5:
				return date < dt || dt < date;
		}
	return false;
};

EventComparisonNode::EventComparisonNode ( const Comparison& c, const string& event ) : ev(event), cmp(c) {};
	
bool EventComparisonNode :: Evaluate( const Date& date, const string& event )  {
		switch (static_cast<int>(cmp)){
			case 0:
				return event < ev;
			case 1:
				return !( event > ev);
			case 2:
				return event > ev;	
			case 3:
				return !( event < ev );
			case 4:
				return event == ev;
			case 5:
				return event != ev;
		}				
		return false;
	};


LogicalOperationNode::LogicalOperationNode( const LogicalOperation& operation, const shared_ptr<Node>& l, const shared_ptr<Node>& curr ) :
																									op(operation), left(l), current(curr) {};

bool LogicalOperationNode::Evaluate( const Date& date, const string& event ) { 
	
	bool result;

	switch(static_cast<int>(op)){
		case 0:
			result = left->Evaluate(date, event) || current->Evaluate(date, event);
			break;
		case 1:
			result = left->Evaluate(date, event) && current->Evaluate(date, event);
			break;
	}
	return result; 
	};
