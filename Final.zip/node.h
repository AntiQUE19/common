#pragma once
#include "date.h"
#include <memory>

using namespace std;

enum class Comparison {
  Less,
  LessOrEqual,
  Greater,
  GreaterOrEqual,
  Equal,
  NotEqual,  
};

enum class LogicalOperation {
	Or,
	And,
};

class Node {
public:
	virtual bool Evaluate( const Date& date, const string& event ) = 0;
};

class EmptyNode : public Node { 
	bool Evaluate( const Date& date, const string& event );
};

class DateComparisonNode : public Node{
public:
	DateComparisonNode( const Comparison& c, const Date& d );
	bool Evaluate( const Date& date, const string& event );
private:
	const Date dt;
	const Comparison cmp;
}; 

class EventComparisonNode : public Node{
public:
	EventComparisonNode( const Comparison& c, const string& event );
	bool Evaluate( const Date& date, const string& event );
private:
	const string ev;
	const Comparison cmp;
};

class LogicalOperationNode : public Node{
public:
	LogicalOperationNode( const LogicalOperation& operation, const shared_ptr<Node>& l, const shared_ptr<Node>& curr );
	bool Evaluate( const Date& date, const string& event );
private:
	const LogicalOperation op;
	const shared_ptr<Node> left;
	const shared_ptr<Node> current;	
};
