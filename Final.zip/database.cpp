#include "database.h"

void  Database::Add( const Date& date, const string& event){
		auto p = bd[date].insert(event);
		if( p.second == true ){
			last[date].push_back(event);
		}
}
	
ostream& Database::Print( ostream& out ) const{
	for( auto item : last ){
		for( auto event : item.second ){
			out << item.first << " " << event << endl;
		}
	}
	return out;
}
	
string Database::Last( const Date& date ) const{
	auto it = last.upper_bound(date);
	if( it == last.begin() ){
		throw invalid_argument("No entries");
	}else{
		it = prev(it);
	}
	
	ostringstream out;
	out << (*it).first << " " << *((*it).second.rbegin());
	return out.str();
}
